'use strict' ;
export.handler =function(event, context, callback) {
 callback(null, 'Serverless Architecture in AWS'
}
